// MainActivity.kt - COMPLETE IT Portfolio Pro Application with CRUD on ALL Pages
// Copy this ENTIRE file - No truncation - Ready to use
package com.example.myapplication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.*
import androidx.compose.ui.text.input.*
import androidx.compose.ui.unit.*
import androidx.compose.ui.window.Dialog
import java.util.UUID
import kotlin.math.*

// ==================== DATA MODELS ====================
data class CustomGoal(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val priority: String = "Medium"
)

data class Tab(val id: String, val name: String, val icon: ImageVector)

data class User(val username: String, val password: String)

data class Pillar(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val freq: String,
    val effort: String,
    val ideas: List<String>
)

data class ScheduleItem(
    val id: String = UUID.randomUUID().toString(),
    val day: String,
    val content: String,
    val platform: String,
    val time: String
)

data class Metric(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val current: String,
    val target: String
)

data class Project(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val description: String,
    val tech: List<String>,
    val status: String
)

data class Skill(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val level: Int
)

data class TeamMember(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val role: String,
    val description: String,
    val skills: List<String>
)

// ==================== MAIN ACTIVITY ====================
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF00F5FF),
                    background = Color(0xFF0A0E27),
                    surface = Color(0xFF1A1F3A)
                )
            ) {
                ContentStrategyApp()
            }
        }
    }
}

// ==================== FUTURISTIC BACKGROUND ====================
@Composable
fun FuturisticBackground(content: @Composable () -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "bg")
    val offset1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(25000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "offset1"
    )
    val offset2 by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(20000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "offset2"
    )
    val offset3 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(30000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "offset3"
    )

    Box(modifier = Modifier.fillMaxSize()) {
        Box(
            Modifier
                .offset(
                    x = (150 + sin(Math.toRadians(offset1.toDouble())) * 80).dp,
                    y = (100 + cos(Math.toRadians(offset1.toDouble())) * 60).dp
                )
                .size(300.dp)
                .blur(80.dp)
                .background(
                    Brush.radialGradient(
                        listOf(
                            Color(0xFF00F5FF).copy(alpha = 0.3f),
                            Color.Transparent
                        )
                    ),
                    CircleShape
                )
        )
        Box(
            Modifier
                .offset(
                    x = (250 + cos(Math.toRadians(offset2.toDouble())) * 100).dp,
                    y = (300 + sin(Math.toRadians(offset2.toDouble())) * 70).dp
                )
                .size(250.dp)
                .blur(70.dp)
                .background(
                    Brush.radialGradient(
                        listOf(
                            Color(0xFFFF006E).copy(alpha = 0.25f),
                            Color.Transparent
                        )
                    ),
                    CircleShape
                )
        )
        Box(
            Modifier
                .offset(
                    x = (50 + sin(Math.toRadians(offset3.toDouble() * 1.5)) * 60).dp,
                    y = (500 + cos(Math.toRadians(offset3.toDouble() * 1.2)) * 80).dp
                )
                .size(280.dp)
                .blur(75.dp)
                .background(
                    Brush.radialGradient(
                        listOf(
                            Color(0xFF8338EC).copy(alpha = 0.28f),
                            Color.Transparent
                        )
                    ),
                    CircleShape
                )
        )
        Box(
            Modifier
                .fillMaxSize()
                .background(Color(0xFF0A0E27).copy(alpha = 0.85f))
        )
        content()
    }
}

// ==================== ANIMATED BUTTON ====================
@Composable
fun AnimatedButton(
    text: String,
    icon: ImageVector? = null,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    gradient: List<Color> = listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
) {
    val scale by animateFloatAsState(
        targetValue = 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 300f),
        label = "scale"
    )
    val infiniteTransition = rememberInfiniteTransition(label = "glow")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow"
    )

    Box(modifier = modifier) {
        Box(
            Modifier
                .matchParentSize()
                .scale(1.05f)
                .alpha(glowAlpha)
                .background(
                    Brush.horizontalGradient(gradient),
                    RoundedCornerShape(16.dp)
                )
                .blur(8.dp)
        )
        Button(
            onClick = onClick,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .scale(scale),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.Transparent
            ),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(2.dp, Brush.horizontalGradient(gradient))
        ) {
            Row(
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (icon != null) {
                    Icon(icon, null, modifier = Modifier.size(24.dp))
                    Spacer(Modifier.width(8.dp))
                }
                Text(
                    text,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodyLarge.copy(
                        brush = Brush.horizontalGradient(gradient)
                    )
                )
            }
        }
    }
}

// ==================== MAIN APP ====================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContentStrategyApp() {
    var isLoggedIn by remember { mutableStateOf(false) }
    var currentUser by remember { mutableStateOf("") }
    var activeTab by remember { mutableStateOf("overview") }

    val validUsers = remember {
        listOf(
            User("admin", "admin123"),
            User("user", "user123")
        )
    }

    val customGoals = remember { mutableStateListOf<CustomGoal>() }

    val pillars = remember {
        mutableStateListOf(
            Pillar(
                "1", "Project Showcases", "2x/month", "High",
                listOf("Case study", "Demo", "Live project")
            ),
            Pillar(
                "2", "Learning Journey", "3x/week", "Medium",
                listOf("Tutorials", "Resources", "Tips")
            ),
            Pillar(
                "3", "Tech Tips", "5x/week", "Low",
                listOf("VS Code", "Git", "Shortcuts")
            )
        )
    }

    val scheduleItems = remember {
        mutableStateListOf(
            ScheduleItem("1", "Monday", "Learning Post", "LinkedIn", "7 PM"),
            ScheduleItem("2", "Tuesday", "Project Showcase", "LinkedIn", "9 AM"),
            ScheduleItem("3", "Wednesday", "Tech Tip", "Twitter", "10 AM")
        )
    }

    val metrics = remember {
        mutableStateListOf(
            Metric("1", "LinkedIn Impressions", "1,200", "5,000/mo"),
            Metric("2", "Engagement Rate", "2.1%", "4%"),
            Metric("3", "GitHub Stars", "45", "100")
        )
    }

    val projects = remember {
        mutableStateListOf(
            Project(
                "1", "Portfolio Website",
                "Personal portfolio with animations",
                listOf("React", "Tailwind"), "Live"
            ),
            Project(
                "2", "Task Manager App",
                "Full-stack task management",
                listOf("Node.js", "MongoDB"), "In Progress"
            )
        )
    }

    val skills = remember {
        mutableStateListOf(
            Skill("1", "React", 85),
            Skill("2", "Kotlin", 75),
            Skill("3", "Python", 80),
            Skill("4", "UI/UX", 70)
        )
    }

    val teamMembers = remember {
        mutableStateListOf(
            TeamMember(
                "1",
                "Parmar Adarsh",
                "Full Stack Developer",
                "Passionate developer with expertise in mobile and web development. Specialized in creating innovative solutions.",
                listOf("Kotlin", "Android", "React", "Node.js")
            ),
            TeamMember(
                "2",
                "Gohil JayveerSinh",
                "Frontend Developer",
                "Creative UI/UX enthusiast focused on building beautiful and intuitive user interfaces.",
                listOf("React", "Tailwind CSS", "JavaScript", "UI/UX")
            ),
            TeamMember(
                "3",
                "Gauswami Harshit Giri",
                "Backend Developer",
                "Backend specialist with strong knowledge in database design and API development.",
                listOf("Python", "MongoDB", "Node.js", "API Design")
            )
        )
    }

    if (!isLoggedIn) {
        LoginScreen(validUsers) { username ->
            currentUser = username
            isLoggedIn = true
        }
        return
    }

    val tabs = listOf(
        Tab("overview", "Overview", Icons.Default.Dashboard),
        Tab("content", "Content", Icons.Default.Book),
        Tab("projects", "Projects", Icons.Default.Code),
        Tab("skills", "Skills", Icons.Default.Psychology),
        Tab("calendar", "Schedule", Icons.Default.CalendarToday),
        Tab("analytics", "Analytics", Icons.Default.BarChart),
        Tab("about", "About Us", Icons.Default.Group)
    )

    FuturisticBackground {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                TopAppBar(
                    title = {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                val rotation by rememberInfiniteTransition(label = "rotation")
                                    .animateFloat(
                                        initialValue = 0f,
                                        targetValue = 360f,
                                        animationSpec = infiniteRepeatable(
                                            animation = tween(4000, easing = LinearEasing),
                                            repeatMode = RepeatMode.Restart
                                        ),
                                        label = "icon_rotation"
                                    )
                                Box(
                                    Modifier
                                        .size(36.dp)
                                        .background(
                                            Brush.linearGradient(
                                                listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                                            ),
                                            CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.TrackChanges,
                                        null,
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp).rotate(rotation)
                                    )
                                }
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Text(
                                        "IT Portfolio Pro",
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        "v3.0 Complete CRUD",
                                        fontSize = 10.sp,
                                        color = Color(0xFF00F5FF)
                                    )
                                }
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    Modifier
                                        .background(Color(0xFF1A1F3A), RoundedCornerShape(12.dp))
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        "Hi, $currentUser",
                                        fontSize = 12.sp,
                                        color = Color(0xFF00F5FF)
                                    )
                                }
                                IconButton(onClick = { isLoggedIn = false }) {
                                    Icon(
                                        Icons.Default.Logout,
                                        "Logout",
                                        tint = Color(0xFFFF006E)
                                    )
                                }
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFF0A0E27).copy(alpha = 0.95f)
                    )
                )
            }
        ) { pad ->
            Column(Modifier.fillMaxSize().padding(pad)) {
                LazyRow(
                    Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1A1F3A).copy(alpha = 0.8f))
                        .padding(vertical = 12.dp, horizontal = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(tabs, key = { _, tab -> tab.id }) { _, tab ->
                        val scale by animateFloatAsState(
                            targetValue = if (activeTab == tab.id) 1.08f else 1f,
                            animationSpec = spring(dampingRatio = 0.7f),
                            label = "scale"
                        )

                        Box(
                            Modifier
                                .scale(scale)
                                .clip(RoundedCornerShape(14.dp))
                                .background(
                                    brush = if (activeTab == tab.id) {
                                        Brush.horizontalGradient(
                                            listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                                        )
                                    } else {
                                        Brush.horizontalGradient(
                                            listOf(Color(0xFF2A2F4A), Color(0xFF1A1F3A))
                                        )
                                    }
                                )
                                .border(
                                    width = if (activeTab == tab.id) 2.dp else 1.dp,
                                    color = if (activeTab == tab.id)
                                        Color(0xFF00F5FF).copy(0.8f)
                                    else
                                        Color(0xFF475569).copy(0.3f),
                                    shape = RoundedCornerShape(14.dp)
                                )
                                .clickable { activeTab = tab.id }
                                .padding(horizontal = 16.dp, vertical = 10.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    tab.icon,
                                    tab.name,
                                    tint = if (activeTab == tab.id)
                                        Color.White
                                    else
                                        Color(0xFF94A3B8),
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    tab.name,
                                    color = if (activeTab == tab.id)
                                        Color.White
                                    else
                                        Color(0xFF94A3B8),
                                    fontSize = 13.sp,
                                    fontWeight = if (activeTab == tab.id)
                                        FontWeight.Bold
                                    else
                                        FontWeight.Normal
                                )
                            }
                        }
                    }
                }

                LazyColumn(
                    Modifier.fillMaxSize().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    when (activeTab) {
                        "overview" -> item { OverviewContent(customGoals) }
                        "content" -> item { ContentPillarsContent(pillars) }
                        "projects" -> item { ProjectsContent(projects) }
                        "skills" -> item { SkillsContent(skills) }
                        "calendar" -> item { CalendarContent(scheduleItems) }
                        "analytics" -> item { AnalyticsContent(metrics) }
                        "about" -> item { AboutUsContent(teamMembers) }
                    }
                }
            }
        }
    }
}

// ==================== LOGIN SCREEN ====================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(validUsers: List<User>, onLoginSuccess: (String) -> Unit) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    val infiniteTransition = rememberInfiniteTransition(label = "login")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    FuturisticBackground {
        Box(
            Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier
                    .offset(x = (-80).dp, y = (-150).dp)
                    .size(350.dp)
                    .scale(scale)
                    .blur(100.dp)
                    .background(
                        Brush.radialGradient(
                            listOf(
                                Color(0xFF00F5FF).copy(alpha = 0.4f),
                                Color.Transparent
                            )
                        ),
                        CircleShape
                    )
            )

            Card(
                Modifier
                    .fillMaxWidth(0.9f)
                    .padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF1A1F3A).copy(alpha = 0.95f)
                ),
                shape = RoundedCornerShape(28.dp),
                border = BorderStroke(
                    2.dp,
                    Brush.linearGradient(
                        listOf(
                            Color(0xFF00F5FF).copy(alpha = 0.5f),
                            Color(0xFF8338EC).copy(alpha = 0.5f)
                        )
                    )
                )
            ) {
                Column(
                    Modifier.padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    Box(
                        Modifier
                            .size(80.dp)
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                                ),
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.TrackChanges,
                            null,
                            tint = Color.White,
                            modifier = Modifier.size(40.dp).rotate(rotation)
                        )
                    }

                    Text(
                        "Welcome Back",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        "Login to your futuristic portfolio",
                        fontSize = 14.sp,
                        color = Color(0xFF94A3B8)
                    )

                    OutlinedTextField(
                        value = username,
                        onValueChange = {
                            username = it
                            errorMessage = ""
                        },
                        label = { Text("Username") },
                        leadingIcon = {
                            Icon(
                                Icons.Default.Person,
                                null,
                                tint = Color(0xFF00F5FF)
                            )
                        },
                        colors = TextFieldDefaults.colors(
                            focusedIndicatorColor = Color(0xFF00F5FF),
                            unfocusedIndicatorColor = Color(0xFF475569),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedLabelColor = Color(0xFF00F5FF)
                        ),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = password,
                        onValueChange = {
                            password = it
                            errorMessage = ""
                        },
                        label = { Text("Password") },
                        leadingIcon = {
                            Icon(
                                Icons.Default.Lock,
                                null,
                                tint = Color(0xFF00F5FF)
                            )
                        },
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    if (passwordVisible)
                                        Icons.Default.Visibility
                                    else
                                        Icons.Default.VisibilityOff,
                                    null,
                                    tint = Color(0xFF94A3B8)
                                )
                            }
                        },
                        visualTransformation = if (passwordVisible)
                            VisualTransformation.None
                        else
                            PasswordVisualTransformation(),
                        colors = TextFieldDefaults.colors(
                            focusedIndicatorColor = Color(0xFF00F5FF),
                            unfocusedIndicatorColor = Color(0xFF475569),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedLabelColor = Color(0xFF00F5FF)
                        ),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    if (errorMessage.isNotEmpty()) {
                        Text(
                            errorMessage,
                            color = Color(0xFFFF006E),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    AnimatedButton(
                        text = "Login",
                        icon = Icons.Default.Login,
                        onClick = {
                            val user = validUsers.find {
                                it.username == username && it.password == password
                            }
                            if (user != null) {
                                onLoginSuccess(username)
                            } else {
                                errorMessage = "Invalid credentials"
                            }
                        }
                    )

                    Text(
                        "Demo: admin/admin123 or user/user123",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

// ==================== OVERVIEW WITH CRUD ====================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OverviewContent(customGoals: MutableList<CustomGoal>) {
    var showDialog by remember { mutableStateOf(false) }
    var editingGoal by remember { mutableStateOf<CustomGoal?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Strategy Overview",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.headlineMedium.copy(
                    brush = Brush.linearGradient(
                        listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                    )
                )
            )
            Box(
                Modifier
                    .size(48.dp)
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                        ),
                        CircleShape
                    )
                    .clickable {
                        editingGoal = null
                        showDialog = true
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Add,
                    "Add",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            listOf(
                Triple("3-6 mo", "First Internship", Color(0xFF00F5FF)),
                Triple("500+", "Connections", Color(0xFF8338EC)),
                Triple("15+", "Projects", Color(0xFFFF006E))
            ).forEach { (value, label, color) ->
                val scale by rememberInfiniteTransition(label = "card").animateFloat(
                    initialValue = 1f,
                    targetValue = 1.05f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(2000, easing = FastOutSlowInEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "scale"
                )

                Card(
                    Modifier
                        .weight(1f)
                        .scale(scale),
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFF1A1F3A).copy(alpha = 0.8f)
                    ),
                    border = BorderStroke(2.dp, color.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        Modifier
                            .padding(14.dp)
                            .fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            value,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = color
                        )
                        Text(
                            label,
                            fontSize = 10.sp,
                            color = Color(0xFF94A3B8),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        Card(
            Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF1A1F3A).copy(alpha = 0.9f)
            ),
            border = BorderStroke(
                2.dp,
                Brush.horizontalGradient(
                    listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                )
            ),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(Modifier.padding(24.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(44.dp)
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                                ),
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.TrackChanges,
                            null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Text(
                        "Primary Goals",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
                Spacer(Modifier.height(16.dp))

                listOf(
                    "Build authority as IT professional",
                    "Attract internship opportunities",
                    "Grow professional network"
                ).forEach { goal ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier
                                .size(8.dp)
                                .background(Color(0xFF00F5FF), CircleShape)
                        )
                        Spacer(Modifier.width(12.dp))
                        Text(
                            goal,
                            fontSize = 15.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }
            }
        }

        Card(
            Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF1A1F3A).copy(alpha = 0.9f)
            ),
            border = BorderStroke(2.dp, Color(0xFF00F5FF).copy(0.3f)),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(Modifier.padding(24.dp)) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Custom Goals",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        "${customGoals.size} goals",
                        fontSize = 12.sp,
                        color = Color(0xFF94A3B8)
                    )
                }

                if (customGoals.isEmpty()) {
                    Spacer(Modifier.height(16.dp))
                    Text(
                        "No custom goals yet. Click + to add one!",
                        fontSize = 14.sp,
                        color = Color(0xFF64748B),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    Spacer(Modifier.height(12.dp))
                    customGoals.forEach { goal ->
                        Card(
                            Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = Color(0xFF0A0E27).copy(0.5f)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        goal.text,
                                        fontSize = 15.sp,
                                        color = Color.White,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Spacer(Modifier.height(4.dp))
                                    Text(
                                        "Priority: ${goal.priority}",
                                        fontSize = 11.sp,
                                        color = when(goal.priority) {
                                            "High" -> Color(0xFFFF006E)
                                            "Medium" -> Color(0xFF00F5FF)
                                            else -> Color(0xFF94A3B8)
                                        }
                                    )
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    IconButton(
                                        onClick = {
                                            editingGoal = goal
                                            showDialog = true
                                        },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Edit,
                                            "Edit",
                                            tint = Color(0xFF00F5FF),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = { customGoals.remove(goal) },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Delete,
                                            "Delete",
                                            tint = Color(0xFFFF006E),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        GoalDialog(
            goal = editingGoal,
            onDismiss = { showDialog = false },
            onSave = { text, priority ->
                if (editingGoal != null) {
                    val index = customGoals.indexOfFirst { it.id == editingGoal!!.id }
                    if (index != -1) {
                        customGoals[index] = CustomGoal(editingGoal!!.id, text, priority)
                    }
                } else {
                    customGoals.add(CustomGoal(text = text, priority = priority))
                }
                showDialog = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoalDialog(
    goal: CustomGoal?,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var text by remember { mutableStateOf(goal?.text ?: "") }
    var priority by remember { mutableStateOf(goal?.priority ?: "Medium") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF1A1F3A)
            ),
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(
                2.dp,
                Brush.linearGradient(
                    listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                )
            )
        ) {
            Column(
                Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    if (goal == null) "Add Goal" else "Edit Goal",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("Goal") },
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color(0xFF00F5FF),
                        unfocusedIndicatorColor = Color(0xFF475569),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedLabelColor = Color(0xFF00F5FF)
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Column {
                    Text(
                        "Priority",
                        fontSize = 14.sp,
                        color = Color(0xFF94A3B8),
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Low", "Medium", "High").forEach { p ->
                            Box(
                                Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        if (priority == p)
                                            Brush.horizontalGradient(
                                                listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                                            )
                                        else
                                            Brush.horizontalGradient(
                                                listOf(Color(0xFF2A2F4A), Color(0xFF1A1F3A))
                                            )
                                    )
                                    .border(
                                        1.dp,
                                        if (priority == p) Color(0xFF00F5FF) else Color(0xFF475569),
                                        RoundedCornerShape(10.dp)
                                    )
                                    .clickable { priority = p }
                                    .padding(vertical = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    p,
                                    fontSize = 13.sp,
                                    color = if (priority == p) Color.White else Color(0xFF94A3B8),
                                    fontWeight = if (priority == p) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF2A2F4A)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Cancel", color = Color.White)
                    }
                    Button(
                        onClick = {
                            if (text.isNotBlank()) {
                                onSave(text, priority)
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.Transparent
                        ),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(
                            2.dp,
                            Brush.horizontalGradient(
                                listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                            )
                        )
                    ) {
                        Text(
                            "Save",
                            style = MaterialTheme.typography.bodyLarge.copy(
                                brush = Brush.horizontalGradient(
                                    listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                                )
                            ),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

// ==================== CONTENT PILLARS WITH CRUD ====================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContentPillarsContent(pillars: MutableList<Pillar>) {
    var showDialog by remember { mutableStateOf(false) }
    var editingPillar by remember { mutableStateOf<Pillar?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Content Pillars",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.headlineMedium.copy(
                    brush = Brush.linearGradient(
                        listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                    )
                )
            )
            Box(
                Modifier
                    .size(48.dp)
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                        ),
                        CircleShape
                    )
                    .clickable {
                        editingPillar = null
                        showDialog = true
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Add,
                    "Add",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        pillars.forEach { pillar ->
            Card(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF1A1F3A).copy(alpha = 0.9f)
                ),
                border = BorderStroke(2.dp, Color(0xFF00F5FF).copy(0.3f)),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(Modifier.padding(20.dp)) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            pillar.title,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            IconButton(
                                onClick = {
                                    editingPillar = pillar
                                    showDialog = true
                                },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    Icons.Default.Edit,
                                    "Edit",
                                    tint = Color(0xFF00F5FF),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            IconButton(
                                onClick = { pillars.remove(pillar) },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    Icons.Default.Delete,
                                    "Delete",
                                    tint = Color(0xFFFF006E),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        InfoChip("Frequency: ${pillar.freq}", Color(0xFF00F5FF))
                        InfoChip("Effort: ${pillar.effort}", Color(0xFF8338EC))
                    }

                    Spacer(Modifier.height(12.dp))

                    Text(
                        "Content Ideas:",
                        fontSize = 13.sp,
                        color = Color(0xFF94A3B8),
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.height(8.dp))

                    pillar.ideas.forEach { idea ->
                        Row(
                            Modifier.padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier
                                    .size(6.dp)
                                    .background(Color(0xFF00F5FF), CircleShape)
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(
                                idea,
                                fontSize = 14.sp,
                                color = Color(0xFFCBD5E1)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        PillarDialog(
            pillar = editingPillar,
            onDismiss = { showDialog = false },
            onSave = { title, freq, effort, ideas ->
                if (editingPillar != null) {
                    val index = pillars.indexOfFirst { it.id == editingPillar!!.id }
                    if (index != -1) {
                        pillars[index] = Pillar(editingPillar!!.id, title, freq, effort, ideas)
                    }
                } else {
                    pillars.add(Pillar(title = title, freq = freq, effort = effort, ideas = ideas))
                }
                showDialog = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PillarDialog(
    pillar: Pillar?,
    onDismiss: () -> Unit,
    onSave: (String, String, String, List<String>) -> Unit
) {
    var title by remember { mutableStateOf(pillar?.title ?: "") }
    var freq by remember { mutableStateOf(pillar?.freq ?: "") }
    var effort by remember { mutableStateOf(pillar?.effort ?: "Medium") }
    var ideasText by remember { mutableStateOf(pillar?.ideas?.joinToString(", ") ?: "") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF1A1F3A)
            ),
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(
                2.dp,
                Brush.linearGradient(
                    listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                )
            )
        ) {
            Column(
                Modifier
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    if (pillar == null) "Add Pillar" else "Edit Pillar",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Title") },
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color(0xFF00F5FF),
                        unfocusedIndicatorColor = Color(0xFF475569),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedLabelColor = Color(0xFF00F5FF)
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                OutlinedTextField(
                    value = freq,
                    onValueChange = { freq = it },
                    label = { Text("Frequency (e.g., 2x/week)") },
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color(0xFF00F5FF),
                        unfocusedIndicatorColor = Color(0xFF475569),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedLabelColor = Color(0xFF00F5FF)
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Column {
                    Text(
                        "Effort Level",
                        fontSize = 14.sp,
                        color = Color(0xFF94A3B8),
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Low", "Medium", "High").forEach { e ->
                            Box(
                                Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        if (effort == e)
                                            Brush.horizontalGradient(
                                                listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                                            )
                                        else
                                            Brush.horizontalGradient(
                                                listOf(Color(0xFF2A2F4A), Color(0xFF1A1F3A))
                                            )
                                    )
                                    .border(
                                        1.dp,
                                        if (effort == e) Color(0xFF00F5FF) else Color(0xFF475569),
                                        RoundedCornerShape(10.dp)
                                    )
                                    .clickable { effort = e }
                                    .padding(vertical = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    e,
                                    fontSize = 13.sp,
                                    color = if (effort == e) Color.White else Color(0xFF94A3B8),
                                    fontWeight = if (effort == e) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = ideasText,
                    onValueChange = { ideasText = it },
                    label = { Text("Ideas (comma-separated)") },
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color(0xFF00F5FF),
                        unfocusedIndicatorColor = Color(0xFF475569),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedLabelColor = Color(0xFF00F5FF)
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    minLines = 3
                )

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF2A2F4A)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Cancel", color = Color.White)
                    }
                    Button(
                        onClick = {
                            if (title.isNotBlank()) {
                                val ideas = ideasText.split(",").map { it.trim() }.filter { it.isNotBlank() }
                                onSave(title, freq, effort, ideas)
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.Transparent
                        ),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(
                            2.dp,
                            Brush.horizontalGradient(
                                listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                            )
                        )
                    ) {
                        Text(
                            "Save",
                            style = MaterialTheme.typography.bodyLarge.copy(
                                brush = Brush.horizontalGradient(
                                    listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                                )
                            ),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun InfoChip(text: String, color: Color) {
    Box(
        Modifier
            .background(
                color.copy(alpha = 0.2f),
                RoundedCornerShape(8.dp)
            )
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text,
            fontSize = 12.sp,
            color = color,
            fontWeight = FontWeight.Medium
        )
    }
}

// ==================== PROJECTS WITH CRUD ====================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectsContent(projects: MutableList<Project>) {
    var showDialog by remember { mutableStateOf(false) }
    var editingProject by remember { mutableStateOf<Project?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Projects",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.headlineMedium.copy(
                    brush = Brush.linearGradient(
                        listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                    )
                )
            )
            Box(
                Modifier
                    .size(48.dp)
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                        ),
                        CircleShape
                    )
                    .clickable {
                        editingProject = null
                        showDialog = true
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Add,
                    "Add",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        projects.forEach { project ->
            Card(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF1A1F3A).copy(alpha = 0.9f)
                ),
                border = BorderStroke(2.dp, Color(0xFF8338EC).copy(0.3f)),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(Modifier.padding(20.dp)) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                project.name,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                project.description,
                                fontSize = 14.sp,
                                color = Color(0xFF94A3B8)
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            IconButton(
                                onClick = {
                                    editingProject = project
                                    showDialog = true
                                },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    Icons.Default.Edit,
                                    "Edit",
                                    tint = Color(0xFF00F5FF),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            IconButton(
                                onClick = { projects.remove(project) },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    Icons.Default.Delete,
                                    "Delete",
                                    tint = Color(0xFFFF006E),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        project.tech.forEach { tech ->
                            Box(
                                Modifier
                                    .background(
                                        Color(0xFF8338EC).copy(alpha = 0.2f),
                                        RoundedCornerShape(6.dp)
                                    )
                                    .padding(horizontal = 10.dp, vertical = 5.dp)
                            ) {
                                Text(
                                    tech,
                                    fontSize = 11.sp,
                                    color = Color(0xFF8338EC),
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    Box(
                        Modifier
                            .background(
                                when (project.status) {
                                    "Live" -> Color(0xFF00F5FF).copy(alpha = 0.2f)
                                    "In Progress" -> Color(0xFFFF006E).copy(alpha = 0.2f)
                                    else -> Color(0xFF94A3B8).copy(alpha = 0.2f)
                                },
                                RoundedCornerShape(8.dp)
                            )
                            .border(
                                1.dp,
                                when (project.status) {
                                    "Live" -> Color(0xFF00F5FF)
                                    "In Progress" -> Color(0xFFFF006E)
                                    else -> Color(0xFF94A3B8)
                                }.copy(alpha = 0.5f),
                                RoundedCornerShape(8.dp)
                            )
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            project.status,
                            fontSize = 12.sp,
                            color = when (project.status) {
                                "Live" -> Color(0xFF00F5FF)
                                "In Progress" -> Color(0xFFFF006E)
                                else -> Color(0xFF94A3B8)
                            },
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }

    if (showDialog) {
        ProjectDialog(
            project = editingProject,
            onDismiss = { showDialog = false },
            onSave = { name, desc, tech, status ->
                if (editingProject != null) {
                    val index = projects.indexOfFirst { it.id == editingProject!!.id }
                    if (index != -1) {
                        projects[index] = Project(editingProject!!.id, name, desc, tech, status)
                    }
                } else {
                    projects.add(Project(name = name, description = desc, tech = tech, status = status))
                }
                showDialog = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectDialog(
    project: Project?,
    onDismiss: () -> Unit,
    onSave: (String, String, List<String>, String) -> Unit
) {
    var name by remember { mutableStateOf(project?.name ?: "") }
    var description by remember { mutableStateOf(project?.description ?: "") }
    var techText by remember { mutableStateOf(project?.tech?.joinToString(", ") ?: "") }
    var status by remember { mutableStateOf(project?.status ?: "Planning") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF1A1F3A)
            ),
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(
                2.dp,
                Brush.linearGradient(
                    listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                )
            )
        ) {
            Column(
                Modifier
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    if (project == null) "Add Project" else "Edit Project",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Project Name") },
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color(0xFF00F5FF),
                        unfocusedIndicatorColor = Color(0xFF475569),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedLabelColor = Color(0xFF00F5FF)
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description") },
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color(0xFF00F5FF),
                        unfocusedIndicatorColor = Color(0xFF475569),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedLabelColor = Color(0xFF00F5FF)
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    minLines = 2
                )

                OutlinedTextField(
                    value = techText,
                    onValueChange = { techText = it },
                    label = { Text("Technologies (comma-separated)") },
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color(0xFF00F5FF),
                        unfocusedIndicatorColor = Color(0xFF475569),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedLabelColor = Color(0xFF00F5FF)
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Column {
                    Text(
                        "Status",
                        fontSize = 14.sp,
                        color = Color(0xFF94A3B8),
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Planning", "In Progress", "Live").forEach { s ->
                            Box(
                                Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        if (status == s)
                                            Brush.horizontalGradient(
                                                listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                                            )
                                        else
                                            Brush.horizontalGradient(
                                                listOf(Color(0xFF2A2F4A), Color(0xFF1A1F3A))
                                            )
                                    )
                                    .border(
                                        1.dp,
                                        if (status == s) Color(0xFF00F5FF) else Color(0xFF475569),
                                        RoundedCornerShape(10.dp)
                                    )
                                    .clickable { status = s }
                                    .padding(vertical = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    s,
                                    fontSize = 11.sp,
                                    color = if (status == s) Color.White else Color(0xFF94A3B8),
                                    fontWeight = if (status == s) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF2A2F4A)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Cancel", color = Color.White)
                    }
                    Button(
                        onClick = {
                            if (name.isNotBlank()) {
                                val tech = techText.split(",").map { it.trim() }.filter { it.isNotBlank() }
                                onSave(name, description, tech, status)
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.Transparent
                        ),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(
                            2.dp,
                            Brush.horizontalGradient(
                                listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                            )
                        )
                    ) {
                        Text(
                            "Save",
                            style = MaterialTheme.typography.bodyLarge.copy(
                                brush = Brush.horizontalGradient(
                                    listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                                )
                            ),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

// ==================== SKILLS WITH CRUD ====================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SkillsContent(skills: MutableList<Skill>) {
    var showDialog by remember { mutableStateOf(false) }
    var editingSkill by remember { mutableStateOf<Skill?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Skills",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.headlineMedium.copy(
                    brush = Brush.linearGradient(
                        listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                    )
                )
            )
            Box(
                Modifier
                    .size(48.dp)
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                        ),
                        CircleShape
                    )
                    .clickable {
                        editingSkill = null
                        showDialog = true
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Add,
                    "Add",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        skills.forEach { skill ->
            Card(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF1A1F3A).copy(alpha = 0.9f)
                ),
                border = BorderStroke(2.dp, Color(0xFF00F5FF).copy(0.3f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            skill.name,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(Modifier.height(10.dp))
                        Row(
                            Modifier.fillMaxWidth(0.9f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier
                                    .weight(1f)
                                    .height(8.dp)
                                    .background(Color(0xFF2A2F4A), RoundedCornerShape(4.dp))
                            ) {
                                Box(
                                    Modifier
                                        .fillMaxWidth(skill.level / 100f)
                                        .height(8.dp)
                                        .background(
                                            Brush.horizontalGradient(
                                                listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                                            ),
                                            RoundedCornerShape(4.dp)
                                        )
                                )
                            }
                            Spacer(Modifier.width(12.dp))
                            Text(
                                "${skill.level}%",
                                fontSize = 14.sp,
                                color = Color(0xFF00F5FF),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(
                            onClick = {
                                editingSkill = skill
                                showDialog = true
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                Icons.Default.Edit,
                                "Edit",
                                tint = Color(0xFF00F5FF),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        IconButton(
                            onClick = { skills.remove(skill) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                Icons.Default.Delete,
                                "Delete",
                                tint = Color(0xFFFF006E),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        SkillDialog(
            skill = editingSkill,
            onDismiss = { showDialog = false },
            onSave = { name, level ->
                if (editingSkill != null) {
                    val index = skills.indexOfFirst { it.id == editingSkill!!.id }
                    if (index != -1) {
                        skills[index] = Skill(editingSkill!!.id, name, level)
                    }
                } else {
                    skills.add(Skill(name = name, level = level))
                }
                showDialog = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SkillDialog(
    skill: Skill?,
    onDismiss: () -> Unit,
    onSave: (String, Int) -> Unit
) {
    var name by remember { mutableStateOf(skill?.name ?: "") }
    var level by remember { mutableStateOf(skill?.level ?: 50) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF1A1F3A)
            ),
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(
                2.dp,
                Brush.linearGradient(
                    listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                )
            )
        ) {
            Column(
                Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    if (skill == null) "Add Skill" else "Edit Skill",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Skill Name") },
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color(0xFF00F5FF),
                        unfocusedIndicatorColor = Color(0xFF475569),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedLabelColor = Color(0xFF00F5FF)
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Column {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            "Proficiency Level",
                            fontSize = 14.sp,
                            color = Color(0xFF94A3B8),
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            "$level%",
                            fontSize = 16.sp,
                            color = Color(0xFF00F5FF),
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    Slider(
                        value = level.toFloat(),
                        onValueChange = { level = it.toInt() },
                        valueRange = 0f..100f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF00F5FF),
                            activeTrackColor = Color(0xFF00F5FF),
                            inactiveTrackColor = Color(0xFF2A2F4A)
                        )
                    )
                }

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF2A2F4A)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Cancel", color = Color.White)
                    }
                    Button(
                        onClick = {
                            if (name.isNotBlank()) {
                                onSave(name, level)
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.Transparent
                        ),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(
                            2.dp,
                            Brush.horizontalGradient(
                                listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                            )
                        )
                    ) {
                        Text(
                            "Save",
                            style = MaterialTheme.typography.bodyLarge.copy(
                                brush = Brush.horizontalGradient(
                                    listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                                )
                            ),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

// ==================== CALENDAR/SCHEDULE WITH CRUD ====================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalendarContent(scheduleItems: MutableList<ScheduleItem>) {
    var showDialog by remember { mutableStateOf(false) }
    var editingItem by remember { mutableStateOf<ScheduleItem?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Content Schedule",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.headlineMedium.copy(
                    brush = Brush.linearGradient(
                        listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                    )
                )
            )
            Box(
                Modifier
                    .size(48.dp)
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                        ),
                        CircleShape
                    )
                    .clickable {
                        editingItem = null
                        showDialog = true
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Add,
                    "Add",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        scheduleItems.forEach { item ->
            Card(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF1A1F3A).copy(alpha = 0.9f)
                ),
                border = BorderStroke(2.dp, Color(0xFF8338EC).copy(0.3f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Box(
                            Modifier
                                .size(60.dp)
                                .background(
                                    Brush.linearGradient(
                                        listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                                    ),
                                    RoundedCornerShape(12.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    item.day.take(3).uppercase(),
                                    fontSize = 12.sp,
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    item.time,
                                    fontSize = 10.sp,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Column(Modifier.weight(1f)) {
                            Text(
                                item.content,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                item.platform,
                                fontSize = 12.sp,
                                color = Color(0xFF00F5FF)
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(
                            onClick = {
                                editingItem = item
                                showDialog = true
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                Icons.Default.Edit,
                                "Edit",
                                tint = Color(0xFF00F5FF),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        IconButton(
                            onClick = { scheduleItems.remove(item) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                Icons.Default.Delete,
                                "Delete",
                                tint = Color(0xFFFF006E),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        ScheduleDialog(
            item = editingItem,
            onDismiss = { showDialog = false },
            onSave = { day, content, platform, time ->
                if (editingItem != null) {
                    val index = scheduleItems.indexOfFirst { it.id == editingItem!!.id }
                    if (index != -1) {
                        scheduleItems[index] = ScheduleItem(editingItem!!.id, day, content, platform, time)
                    }
                } else {
                    scheduleItems.add(ScheduleItem(day = day, content = content, platform = platform, time = time))
                }
                showDialog = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScheduleDialog(
    item: ScheduleItem?,
    onDismiss: () -> Unit,
    onSave: (String, String, String, String) -> Unit
) {
    var day by remember { mutableStateOf(item?.day ?: "Monday") }
    var content by remember { mutableStateOf(item?.content ?: "") }
    var platform by remember { mutableStateOf(item?.platform ?: "LinkedIn") }
    var time by remember { mutableStateOf(item?.time ?: "9 AM") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF1A1F3A)
            ),
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(
                2.dp,
                Brush.linearGradient(
                    listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                )
            )
        ) {
            Column(
                Modifier
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    if (item == null) "Add Schedule" else "Edit Schedule",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Column {
                    Text(
                        "Day",
                        fontSize = 14.sp,
                        color = Color(0xFF94A3B8),
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")) { d ->
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        if (day == d)
                                            Brush.horizontalGradient(
                                                listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                                            )
                                        else
                                            Brush.horizontalGradient(
                                                listOf(Color(0xFF2A2F4A), Color(0xFF1A1F3A))
                                            )
                                    )
                                    .border(
                                        1.dp,
                                        if (day == d) Color(0xFF00F5FF) else Color(0xFF475569),
                                        RoundedCornerShape(10.dp)
                                    )
                                    .clickable { day = d }
                                    .padding(horizontal = 16.dp, vertical = 10.dp)
                            ) {
                                Text(
                                    d.take(3),
                                    fontSize = 13.sp,
                                    color = if (day == d) Color.White else Color(0xFF94A3B8),
                                    fontWeight = if (day == d) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("Content Type") },
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color(0xFF00F5FF),
                        unfocusedIndicatorColor = Color(0xFF475569),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedLabelColor = Color(0xFF00F5FF)
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Column {
                    Text(
                        "Platform",
                        fontSize = 14.sp,
                        color = Color(0xFF94A3B8),
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("LinkedIn", "Twitter", "GitHub", "Blog").forEach { p ->
                            Box(
                                Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        if (platform == p)
                                            Brush.horizontalGradient(
                                                listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                                            )
                                        else
                                            Brush.horizontalGradient(
                                                listOf(Color(0xFF2A2F4A), Color(0xFF1A1F3A))
                                            )
                                    )
                                    .border(
                                        1.dp,
                                        if (platform == p) Color(0xFF00F5FF) else Color(0xFF475569),
                                        RoundedCornerShape(10.dp)
                                    )
                                    .clickable { platform = p }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    p,
                                    fontSize = 11.sp,
                                    color = if (platform == p) Color.White else Color(0xFF94A3B8),
                                    fontWeight = if (platform == p) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = time,
                    onValueChange = { time = it },
                    label = { Text("Time (e.g., 9 AM)") },
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color(0xFF00F5FF),
                        unfocusedIndicatorColor = Color(0xFF475569),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedLabelColor = Color(0xFF00F5FF)
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF2A2F4A)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Cancel", color = Color.White)
                    }
                    Button(
                        onClick = {
                            if (content.isNotBlank()) {
                                onSave(day, content, platform, time)
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.Transparent
                        ),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(
                            2.dp,
                            Brush.horizontalGradient(
                                listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                            )
                        )
                    ) {
                        Text(
                            "Save",
                            style = MaterialTheme.typography.bodyLarge.copy(
                                brush = Brush.horizontalGradient(
                                    listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                                )
                            ),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

// ==================== ANALYTICS WITH CRUD ====================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyticsContent(metrics: MutableList<Metric>) {
    var showDialog by remember { mutableStateOf(false) }
    var editingMetric by remember { mutableStateOf<Metric?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Analytics & Metrics",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.headlineMedium.copy(
                    brush = Brush.linearGradient(
                        listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                    )
                )
            )
            Box(
                Modifier
                    .size(48.dp)
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                        ),
                        CircleShape
                    )
                    .clickable {
                        editingMetric = null
                        showDialog = true
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Add,
                    "Add",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        metrics.forEach { metric ->
            Card(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF1A1F3A).copy(alpha = 0.9f)
                ),
                border = BorderStroke(2.dp, Color(0xFFFF006E).copy(0.3f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            metric.name,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier
                                    .background(
                                        Color(0xFF00F5FF).copy(alpha = 0.2f),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    "Current: ${metric.current}",
                                    fontSize = 13.sp,
                                    color = Color(0xFF00F5FF),
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            Icon(
                                Icons.Default.ArrowForward,
                                null,
                                tint = Color(0xFF94A3B8),
                                modifier = Modifier.size(16.dp)
                            )
                            Box(
                                Modifier
                                    .background(
                                        Color(0xFF8338EC).copy(alpha = 0.2f),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    "Target: ${metric.target}",
                                    fontSize = 13.sp,
                                    color = Color(0xFF8338EC),
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(
                            onClick = {
                                editingMetric = metric
                                showDialog = true
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                Icons.Default.Edit,
                                "Edit",
                                tint = Color(0xFF00F5FF),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        IconButton(
                            onClick = { metrics.remove(metric) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                Icons.Default.Delete,
                                "Delete",
                                tint = Color(0xFFFF006E),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        MetricDialog(
            metric = editingMetric,
            onDismiss = { showDialog = false },
            onSave = { name, current, target ->
                if (editingMetric != null) {
                    val index = metrics.indexOfFirst { it.id == editingMetric!!.id }
                    if (index != -1) {
                        metrics[index] = Metric(editingMetric!!.id, name, current, target)
                    }
                } else {
                    metrics.add(Metric(name = name, current = current, target = target))
                }
                showDialog = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MetricDialog(
    metric: Metric?,
    onDismiss: () -> Unit,
    onSave: (String, String, String) -> Unit
) {
    var name by remember { mutableStateOf(metric?.name ?: "") }
    var current by remember { mutableStateOf(metric?.current ?: "") }
    var target by remember { mutableStateOf(metric?.target ?: "") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF1A1F3A)
            ),
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(
                2.dp,
                Brush.linearGradient(
                    listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                )
            )
        ) {
            Column(
                Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    if (metric == null) "Add Metric" else "Edit Metric",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Metric Name") },
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color(0xFF00F5FF),
                        unfocusedIndicatorColor = Color(0xFF475569),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedLabelColor = Color(0xFF00F5FF)
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                OutlinedTextField(
                    value = current,
                    onValueChange = { current = it },
                    label = { Text("Current Value") },
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color(0xFF00F5FF),
                        unfocusedIndicatorColor = Color(0xFF475569),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedLabelColor = Color(0xFF00F5FF)
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                OutlinedTextField(
                    value = target,
                    onValueChange = { target = it },
                    label = { Text("Target Value") },
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color(0xFF00F5FF),
                        unfocusedIndicatorColor = Color(0xFF475569),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedLabelColor = Color(0xFF00F5FF)
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF2A2F4A)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Cancel", color = Color.White)
                    }
                    Button(
                        onClick = {
                            if (name.isNotBlank()) {
                                onSave(name, current, target)
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.Transparent
                        ),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(
                            2.dp,
                            Brush.horizontalGradient(
                                listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                            )
                        )
                    ) {
                        Text(
                            "Save",
                            style = MaterialTheme.typography.bodyLarge.copy(
                                brush = Brush.horizontalGradient(
                                    listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                                )
                            ),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

// ==================== ABOUT US PAGE WITH CRUD ====================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutUsContent(teamMembers: MutableList<TeamMember>) {
    var showDialog by remember { mutableStateOf(false) }
    var editingMember by remember { mutableStateOf<TeamMember?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "About Us",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.headlineMedium.copy(
                    brush = Brush.linearGradient(
                        listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                    )
                )
            )
            Box(
                Modifier
                    .size(48.dp)
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                        ),
                        CircleShape
                    )
                    .clickable {
                        editingMember = null
                        showDialog = true
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Add,
                    "Add",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        Card(
            Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF1A1F3A).copy(alpha = 0.9f)
            ),
            border = BorderStroke(
                2.dp,
                Brush.horizontalGradient(
                    listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                )
            ),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(
                Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    Modifier
                        .size(80.dp)
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                            ),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Group,
                        null,
                        tint = Color.White,
                        modifier = Modifier.size(40.dp)
                    )
                }
                Spacer(Modifier.height(16.dp))
                Text(
                    "Our Team",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "Meet the talented individuals behind IT Portfolio Pro",
                    fontSize = 14.sp,
                    color = Color(0xFF94A3B8),
                    textAlign = TextAlign.Center
                )
            }
        }

        teamMembers.forEachIndexed { index, member ->
            val colors = listOf(
                listOf(Color(0xFF00F5FF), Color(0xFF8338EC)),
                listOf(Color(0xFF8338EC), Color(0xFFFF006E)),
                listOf(Color(0xFFFF006E), Color(0xFF00F5FF))
            )
            val memberColor = colors[index % colors.size]

            Card(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF1A1F3A).copy(alpha = 0.9f)
                ),
                border = BorderStroke(
                    2.dp,
                    Brush.horizontalGradient(memberColor)
                ),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(Modifier.padding(20.dp)) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Row(
                            Modifier.weight(1f),
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Box(
                                Modifier
                                    .size(70.dp)
                                    .background(
                                        Brush.linearGradient(memberColor),
                                        CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    member.name.split(" ").map { it.first() }.joinToString(""),
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                            Column(Modifier.weight(1f)) {
                                Text(
                                    member.name,
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    member.role,
                                    fontSize = 14.sp,
                                    color = memberColor[0],
                                    fontWeight = FontWeight.Medium
                                )
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    member.description,
                                    fontSize = 13.sp,
                                    color = Color(0xFF94A3B8),
                                    lineHeight = 18.sp
                                )
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            IconButton(
                                onClick = {
                                    editingMember = member
                                    showDialog = true
                                },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    Icons.Default.Edit,
                                    "Edit",
                                    tint = memberColor[0],
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            IconButton(
                                onClick = { teamMembers.remove(member) },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    Icons.Default.Delete,
                                    "Delete",
                                    tint = Color(0xFFFF006E),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    Text(
                        "Skills:",
                        fontSize = 13.sp,
                        color = Color(0xFF94A3B8),
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.height(8.dp))

                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        member.skills.forEach { skill ->
                            Box(
                                Modifier
                                    .background(
                                        memberColor[0].copy(alpha = 0.2f),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .border(
                                        1.dp,
                                        memberColor[0].copy(alpha = 0.5f),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    skill,
                                    fontSize = 12.sp,
                                    color = memberColor[0],
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        TeamMemberDialog(
            member = editingMember,
            onDismiss = { showDialog = false },
            onSave = { name, role, desc, skills ->
                if (editingMember != null) {
                    val index = teamMembers.indexOfFirst { it.id == editingMember!!.id }
                    if (index != -1) {
                        teamMembers[index] = TeamMember(editingMember!!.id, name, role, desc, skills)
                    }
                } else {
                    teamMembers.add(TeamMember(name = name, role = role, description = desc, skills = skills))
                }
                showDialog = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeamMemberDialog(
    member: TeamMember?,
    onDismiss: () -> Unit,
    onSave: (String, String, String, List<String>) -> Unit
) {
    var name by remember { mutableStateOf(member?.name ?: "") }
    var role by remember { mutableStateOf(member?.role ?: "") }
    var description by remember { mutableStateOf(member?.description ?: "") }
    var skillsText by remember { mutableStateOf(member?.skills?.joinToString(", ") ?: "") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF1A1F3A)
            ),
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(
                2.dp,
                Brush.linearGradient(
                    listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                )
            )
        ) {
            Column(
                Modifier
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    if (member == null) "Add Team Member" else "Edit Team Member",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name") },
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color(0xFF00F5FF),
                        unfocusedIndicatorColor = Color(0xFF475569),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedLabelColor = Color(0xFF00F5FF)
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                OutlinedTextField(
                    value = role,
                    onValueChange = { role = it },
                    label = { Text("Role") },
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color(0xFF00F5FF),
                        unfocusedIndicatorColor = Color(0xFF475569),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedLabelColor = Color(0xFF00F5FF)
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description") },
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color(0xFF00F5FF),
                        unfocusedIndicatorColor = Color(0xFF475569),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedLabelColor = Color(0xFF00F5FF)
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    minLines = 3
                )

                OutlinedTextField(
                    value = skillsText,
                    onValueChange = { skillsText = it },
                    label = { Text("Skills (comma-separated)") },
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color(0xFF00F5FF),
                        unfocusedIndicatorColor = Color(0xFF475569),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedLabelColor = Color(0xFF00F5FF)
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    minLines = 2
                )

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF2A2F4A)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Cancel", color = Color.White)
                    }
                    Button(
                        onClick = {
                            if (name.isNotBlank() && role.isNotBlank()) {
                                val skills = skillsText.split(",").map { it.trim() }.filter { it.isNotBlank() }
                                onSave(name, role, description, skills)
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.Transparent
                        ),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(
                            2.dp,
                            Brush.horizontalGradient(
                                listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                            )
                        )
                    ) {
                        Text(
                            "Save",
                            style = MaterialTheme.typography.bodyLarge.copy(
                                brush = Brush.horizontalGradient(
                                    listOf(Color(0xFF00F5FF), Color(0xFF8338EC))
                                )
                            ),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}